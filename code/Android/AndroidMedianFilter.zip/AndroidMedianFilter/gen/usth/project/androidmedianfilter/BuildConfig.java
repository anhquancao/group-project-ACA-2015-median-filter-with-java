/** Automatically generated file. DO NOT MODIFY */
package usth.project.androidmedianfilter;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}