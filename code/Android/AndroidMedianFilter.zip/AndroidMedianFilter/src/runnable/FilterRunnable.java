/**
 * Author : Cao Anh Quan
 */
package runnable;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import usth.project.androidmedianfilter.MainActivity;
import android.graphics.Bitmap;
import android.graphics.Color;

public class FilterRunnable implements Runnable {

	private int mStartRow, mEndRow;
	private Bitmap mImage;
	private Bitmap mOrigin;
	private int mNumberOfRuns = 1;
	private int mWindowSize;

	/**
	 * Constructor
	 * 
	 * @param start
	 *            Starting Index
	 * @param end
	 *            Ending Index
	 * @param image
	 *            Image to be filtered
	 * @param numRun
	 *            Number of run times
	 * @param testThreads
	 *            Whether or not keep all theads running
	 */
	public FilterRunnable(int start, int end, Bitmap image, int numRun,
			int windowSize) {
		// TODO Auto-generated constructor stub
		mStartRow = start;
		mEndRow = end;
		mImage = image;
		mOrigin = MainActivity.resize(mImage, mImage.getWidth());
		mNumberOfRuns = numRun;
		mWindowSize = windowSize;
	}

	/**
	 * Copy the image
	 * 
	 * @param bi
	 *            The input image
	 * @return BufferedIamge
	 */

	@Override
	public void run() {
		// Run the median filter
		medianFilter(mImage, mStartRow, mEndRow, mWindowSize);

	}

	/**
	 * Median filter
	 * 
	 * @param img
	 *            The input image
	 * @param rowStart
	 *            The stating row
	 * @param rowEnd
	 *            The ending row
	 * @return BufferedImage after filtering
	 */
	public Bitmap medianFilter(Bitmap img, int rowStart, int rowEnd,
			int windowSize) {
		// File f = new File("photo.jpg"); // Input Photo File
		int num = windowSize * windowSize;
		// Create the array to contain color of num pixels around
		int[] pixel = new int[num];

		// The R, G ,B array to contain the R, G, B value for each pixel
		int[] R = new int[num];
		int[] B = new int[num];
		int[] G = new int[num];

		int i = windowSize / 2 + 1;
		for (; i < img.getWidth() - 1; i++)
			for (int j = rowStart; j < rowEnd; j++) {
				int index = 0;
				for (int k = -(windowSize / 2); k <= (windowSize / 2); k++) {
					for (int m = -(windowSize / 2); m <= (windowSize / 2); m++) {
						if (index == num) {
							break;
						}
						try {
							pixel[index] = mOrigin.getPixel(i + k, j + m);
						} catch (Exception e) {

						}
						index += 1;

					}
				}

				for (int k = 0; k < num; k++) {
					R[k] = Color.red(pixel[k]);
					B[k] = Color.blue(pixel[k]);
					G[k] = Color.green(pixel[k]);
				}
				// Sort the array then get the median
				Arrays.sort(R);
				Arrays.sort(G);
				Arrays.sort(B);
				img.setPixel(i, j,
						Color.rgb(R[num / 2], G[num / 2], B[num / 2]));
			}

		return img;
	}

	/**
	 * Get the filtered image
	 * 
	 * @return BufferedImage
	 */
	public Bitmap getFileredImage() {
		return mImage;
	}
}
