/**
 * Author : Cao Anh Quan
 */
package usth.project.androidmedianfilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import runnable.FilterRunnable;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements
		NumberPicker.OnValueChangeListener {

	private ImageView mImageView;
	private Button mFilterButton;
	private Button mButtonBrowse;
	private TextView mTxtDetail;
	private Bitmap mCurrentImage;
	public static final String IMAGE_PASS = "com.usth.project.androidmedianfilter.IMAGE_PASS";
	public static final int IMAGE_WIDTH = 800;
	private int PICK_IMAGE_REQUEST = 1995;
	private Bitmap mOrigin;
	private int mNumberOfRuns = 1;
	private int mCurNumThreads = 1;
	private int mWindowSize = 3;
	private int mCurrentSetting;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mImageView = (ImageView) findViewById(R.id.originImage);		
		mTxtDetail = (TextView) findViewById(R.id.txtDetail);
		updateState();
		mCurrentImage = ((BitmapDrawable) mImageView.getDrawable()).getBitmap();
		mCurrentImage = resize(mCurrentImage, IMAGE_WIDTH);
		mOrigin = resize(mCurrentImage, mCurrentImage.getWidth());
		mImageView.setImageBitmap(mCurrentImage);
	}

	private void updateState() {
		mTxtDetail.setText("Number of Threads " + mCurNumThreads
				+ "\nNumber of Runs: " + mNumberOfRuns + "\nWindow Size: "
				+ mWindowSize);
	}

	private void chooseImage() {
		Intent intent = new Intent();
		intent.setType("image/*");
		intent.setAction(Intent.ACTION_GET_CONTENT);
		startActivityForResult(Intent.createChooser(intent, "Select Picture"),
				PICK_IMAGE_REQUEST);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		if (id == R.id.num_threads) {
			show("Number of Threads", R.id.num_threads);
			return true;
		}
		if (id == R.id.num_runs) {
			show("Number of Runs", R.id.num_runs);
			return true;
		}
		if (id == R.id.window_size) {
			show("Window Size", R.id.window_size);
			return true;
		}

		if (id == R.id.Browse) {
			chooseImage();
			return true;
		}
		if (id == R.id.run_filter) {
			runMedianFilter();
			return true;
		}
		if (id == R.id.reset) {
			mCurrentImage = resize(mOrigin, mOrigin.getWidth());
			mImageView.setImageBitmap(mCurrentImage);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
				&& data != null && data.getData() != null) {
			Uri uri = data.getData();
			try {
				Bitmap temp = MediaStore.Images.Media.getBitmap(
						getContentResolver(), uri);
				mCurrentImage = resize(temp, IMAGE_WIDTH);
				mImageView.setImageBitmap(mCurrentImage);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}

	public static Bitmap resize(Bitmap input, int width) {
		return Bitmap.createScaledBitmap(input, width, (int) (IMAGE_WIDTH
				* (double) input.getHeight() / input.getWidth()), true);
	}

	public void show(String title, int id) {

		mCurrentSetting = id;
		final Dialog d = new Dialog(MainActivity.this);
		d.setTitle(title);
		d.setContentView(R.layout.setting_dialog);
		Button b1 = (Button) d.findViewById(R.id.button1);
		final NumberPicker np = (NumberPicker) d
				.findViewById(R.id.numberPicker1);
		np.setMaxValue(30);
		if (id == R.id.window_size) {
			np.setMinValue(3);
		} else {
			np.setMinValue(1);
		}
		np.setMaxValue(100);
		np.setMinValue(0);
		np.setWrapSelectorWheel(false);
		np.setOnValueChangedListener(this);

		b1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (mWindowSize % 2 != 1) {
					mWindowSize -= 1;
					Toast.makeText(
							getApplicationContext(),
							"Window Size must be Odd number, Automatic set to "
									+ mWindowSize, Toast.LENGTH_SHORT).show();
				}
				updateState();
				d.dismiss();
			}
		});
		d.show();

	}

	/**
	 * Run the median filter on the choosed image
	 */
	protected void runMedianFilter() {
		/**
		 * 
		 * The Java Virtual Machine allows an application to have multiple
		 * threads of execution running concurrently. Every thread has a
		 * priority. Threads with higher priority are executed in preference to
		 * threads with lower priority. Each thread may or may not also be
		 * marked as a daemon. When code running in some thread creates a new
		 * Thread object, the new thread has its priority initially set equal to
		 * the priority of the creating thread, and is a daemon thread if and
		 * only if the creating thread is a daemon.
		 *
		 * When a Java Virtual Machine starts up, there is usually a single
		 * non-daemon thread (which typically calls the method named main of
		 * some designated class). The Java Virtual Machine continues to execute
		 * threads until either of the following occurs:
		 *
		 * The exit method of class Runtime has been called and the security
		 * manager has permitted the exit operation to take place. All threads
		 * that are not daemon threads have died, either by returning from the
		 * call to the run method or by throwing an exception that propagates
		 * beyond the run method.
		 *
		 * 
		 */

		// copy the origin image
		mOrigin = resize(mCurrentImage, mCurrentImage.getWidth());

		long timeStart = new Date().getTime();

		// run the filter mNumberOfRuns times
		for (int j = 0; j < mNumberOfRuns; j++) {

			// set the original image to mImage
			mCurrentImage = resize(mOrigin, mOrigin.getWidth());

			// create the list to contain the thread
			ArrayList<Thread> threads = new ArrayList<Thread>();

			// get the interval to run several threads
			int interval = mCurrentImage.getHeight() / mCurNumThreads;

			// add the first thread to list
			threads.add(new Thread(new FilterRunnable(mWindowSize / 2, interval
					- mWindowSize / 2, mCurrentImage, mNumberOfRuns,
					mWindowSize)));
			for (int i = 2; i < mCurNumThreads + 1; i++) {

				// add the other threads
				threads.add(new Thread(new FilterRunnable((i - 1) * interval
						- mWindowSize / 2, interval * i - mWindowSize / 2,
						mCurrentImage, mNumberOfRuns, mWindowSize)));

			}

			// start all theads in the list
			for (Thread thread : threads) {
				thread.start();
			}

			try {
				// join all thread
				for (Thread thread : threads) {
					thread.join();
				}
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
		}

		// get the end time
		long timeEnd = new Date().getTime();

		// compute the run time in milliseconds
		long runTime = timeEnd - timeStart;
		mImageView.setImageBitmap(mCurrentImage);
		Toast.makeText(getApplicationContext(), "Runtime: " + runTime,
				Toast.LENGTH_LONG).show();

	}

	@Override
	public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
		if (mCurrentSetting == R.id.num_threads) {
			mCurNumThreads = newVal;
			if (mCurNumThreads == 0) {
				mCurNumThreads = 1;
				Toast.makeText(getApplicationContext(), "Minimum value is 1",
						Toast.LENGTH_SHORT).show();
			}

		}
		if (mCurrentSetting == R.id.num_runs) {
			mNumberOfRuns = newVal;
			if (mNumberOfRuns == 0) {
				mNumberOfRuns = 1;
				Toast.makeText(getApplicationContext(), "Minimum value is 1",
						Toast.LENGTH_SHORT).show();
			}

		}
		if (mCurrentSetting == R.id.window_size) {
			mWindowSize = newVal;
			if (mWindowSize < 3) {
				mWindowSize = 3;
				Toast.makeText(getApplicationContext(), "Minimum value is 3",
						Toast.LENGTH_SHORT).show();
			}

		}
		updateState();
	}
}
