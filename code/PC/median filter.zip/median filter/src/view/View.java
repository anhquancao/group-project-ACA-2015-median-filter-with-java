/**

 * The median filter program implements an application that
 * simply run median filter on the image
 * get number of threads: ps -o nlwp <pid>
 * cpu information : top -H -p <pid>
 * @author  Cao Anh Quan
 * @version 1.0
 * @since   2015-04-12 
 */
package view;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

import panel.ImagePreviewPanel;
import runnable.FilterRunnable;
import dialog.ResultDialog;

public class View {
	/** the main frame */
	private JFrame mainFrame;

	private JLabel mLabel;

	/** the width of the display image */
	private static final int IMAGE_WIDTH = 800;
	/** button open the chooser */
	private JButton openButton;

	/** button to filter the image */
	private JButton filterButton;

	/** the image to be filter */
	private BufferedImage mImage;

	/** the panel to keep all the button */
	private JPanel mButtonPanel;

	/** number of threads to run */
	private int mCurNumThreads = 1;

	/** window size */
	private int mWindowSize = 3;

	/** the original image */
	private BufferedImage mOrigin;

	/** the input field for the number of threads */
	private JTextField mTxtNumTheads;

	/** number of runs for testing */
	private int mNumberOfRuns = 1;

	/** Runtime */
	private long mRuntime;

	/** the input file for the number of runs */
	private JTextField mTxtNumRuns;
	private boolean mKeepThreadsRunning = false;
	private JCheckBox mCbKeepAllThreadsRunning;

	private JTextField mTxtWindowSize;
	/** Run all the test cases */
	private JButton mAutonomousTest;

	/**
	 * Constructor Call the initUI() method to initiate the UI
	 */
	public View() {
		initUI();
	}

	/**
	 * This method resize the image and then return BufferedImage
	 * 
	 * @param path
	 *            String This is the path of image file
	 * @return image BufferedImage This return the image
	 */
	private BufferedImage resizedImage(String path) {
		File file = new File(path);
		BufferedImage image = null;
		try {
			BufferedImage rawImage = ImageIO.read(file);
			image = resize(rawImage, IMAGE_WIDTH,
					(IMAGE_WIDTH * rawImage.getHeight()) / rawImage.getWidth());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return image;
	}

	/**
	 * Initiate the UI
	 */
	private void initUI() {
		// init the mainFrame object
		mainFrame = new JFrame("Median Filter - Cao Anh Quan");

		// load the image from file, resize then display the image
		mImage = resizedImage("photo.jpg");
		mLabel = new JLabel(new ImageIcon(mImage));

		// Create the filter button
		filterButton = new JButton("Filter Image");

		// ActionListener for the filter button
		filterButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// Run the median filter
				runMedianFilter(false);
			}
		});

		// create the choose image button
		openButton = new JButton("Open");

		// ActionListener for choose image button
		openButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// Open the image chooser to choose the image
				runChooseImage();
			}
		});

		JLabel lbNumThreads = new JLabel("Number of Threads: ");

		// Create input field for the number of threads
		mTxtNumTheads = new JTextField();
		// set the size for the mTxtNumThreads
		mTxtNumTheads.setPreferredSize(new Dimension(30, 25));
		// set the default number of thread to 1
		mTxtNumTheads.setText("1");
		// add ActionListener
		mTxtNumTheads.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// Get the input for the number of threads
				mCurNumThreads = Integer.parseInt(mTxtNumTheads.getText());
				// Get the number of available processors
				int processors = Runtime.getRuntime().availableProcessors();
				// print to console for debugging
				System.out.println("Number of threads: " + mCurNumThreads);
				System.out.println("Number of processors: " + processors);
				// Show the message dialog to indicate the modification
				JOptionPane.showMessageDialog(mainFrame, "Number of threads: "
						+ mCurNumThreads + "\nNumber of processors: "
						+ processors);

			}
		});

		JLabel lbNumRuns = new JLabel("Number of Runs: ");

		// Input field for the number of runs
		mTxtNumRuns = new JTextField();

		// Set default number of runs to 1
		mTxtNumRuns.setText("1");

		// Set size for mTxtNumRuns
		mTxtNumRuns.setPreferredSize(new Dimension(30, 25));

		// Add ActionListener
		mTxtNumRuns.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					mNumberOfRuns = Integer.parseInt(mTxtNumRuns.getText());
				} catch (Exception e1) {

				}
				// Print out to console for debugging
				System.out.println("Number of run times: " + mNumberOfRuns);
				// Show message dialog to notify change
				JOptionPane.showMessageDialog(mainFrame,
						"Number of run times: " + mNumberOfRuns);

			}
		});

		// Textfield to set the Window size
		JLabel lbWindowSize = new JLabel("Window Size: ");

		// Input field for the number of runs
		mTxtWindowSize = new JTextField();

		// Set default number of runs to 1
		mTxtWindowSize.setText("3");

		// Set size for mTxtNumRuns
		mTxtWindowSize.setPreferredSize(new Dimension(30, 25));

		// Add ActionListener
		mTxtWindowSize.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					mWindowSize = Integer.parseInt(mTxtWindowSize.getText());
					if (mWindowSize % 2 == 0) {
						mWindowSize -= 1;
					}
					if (mWindowSize < 3) {
						mWindowSize = 3;
					}
					mTxtWindowSize.setText(mWindowSize + "");
				} catch (Exception e1) {

				}
				// Print out to console for debugging
				System.out.println("Window Size: " + mWindowSize);
				// Show message dialog to notify change
				JOptionPane.showMessageDialog(mainFrame, "Window Size: "
						+ mWindowSize + " x " + mWindowSize);

			}
		});

		// button to run all the test
		mAutonomousTest = new JButton("Autonomous Test");
		mAutonomousTest.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				autonomoustTest();

			}
		});

		// create button panel to contain all buttons
		mButtonPanel = new JPanel();
		mButtonPanel.setLayout(new FlowLayout());
		mButtonPanel.add(openButton);
		mButtonPanel.add(filterButton);
		mButtonPanel.add(lbNumThreads);
		mButtonPanel.add(mTxtNumTheads);
		mButtonPanel.add(lbNumRuns);
		mButtonPanel.add(mTxtNumRuns);
		mButtonPanel.add(mAutonomousTest);
		mButtonPanel.add(lbWindowSize);
		mButtonPanel.add(mTxtWindowSize);

		// set the layout and add the necessary component
		mainFrame.getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER));
		mainFrame.getContentPane().add(mLabel);
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainFrame.getContentPane().add(mButtonPanel);
		mainFrame.setSize(IMAGE_WIDTH,
				mImage.getHeight() + 90 + mButtonPanel.getHeight());
		mainFrame.setVisible(true);
	}

	/**
	 * Run image chooser to choose the image
	 */
	protected void runChooseImage() {
		JFileChooser chooser = new JFileChooser();

		// set default directory for the JFileChooser
		chooser.setCurrentDirectory(new File("/home/quan/Desktop/Images"));

		// create the extension filter for .jpg image
		FileNameExtensionFilter filter = new FileNameExtensionFilter(
				"JPG images", "jpg");

		// set filter for chooser
		chooser.setFileFilter(filter);

		// Create the preview panel to preview the images
		ImagePreviewPanel preview = new ImagePreviewPanel();
		chooser.setAccessory(preview);
		chooser.addPropertyChangeListener(preview);

		// show the dialog to choose the image
		int returnVal = chooser.showOpenDialog(mainFrame);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			try {
				// get the selected image
				BufferedImage rawImage = ImageIO
						.read(chooser.getSelectedFile());
				BufferedImage image = resize(
						rawImage,
						IMAGE_WIDTH,
						(IMAGE_WIDTH * rawImage.getHeight())
								/ rawImage.getWidth());
				mLabel.setIcon(new ImageIcon(image));
				mImage = image;

				mainFrame.setSize(IMAGE_WIDTH, mImage.getHeight() + 60
						+ mButtonPanel.getHeight());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

	/**
	 * Run the median filter on the choosed image
	 */
	protected void runMedianFilter(boolean runAllTestMode) {
		/**
		 * 
		 * The Java Virtual Machine allows an application to have multiple
		 * threads of execution running concurrently. Every thread has a
		 * priority. Threads with higher priority are executed in preference to
		 * threads with lower priority. Each thread may or may not also be
		 * marked as a daemon. When code running in some thread creates a new
		 * Thread object, the new thread has its priority initially set equal to
		 * the priority of the creating thread, and is a daemon thread if and
		 * only if the creating thread is a daemon.
		 *
		 * When a Java Virtual Machine starts up, there is usually a single
		 * non-daemon thread (which typically calls the method named main of
		 * some designated class). The Java Virtual Machine continues to execute
		 * threads until either of the following occurs:
		 *
		 * The exit method of class Runtime has been called and the security
		 * manager has permitted the exit operation to take place. All threads
		 * that are not daemon threads have died, either by returning from the
		 * call to the run method or by throwing an exception that propagates
		 * beyond the run method.
		 *
		 * 
		 */

		// copy the origin image
		mOrigin = FilterRunnable.deepCopy(mImage);

		// get the starting time
		long timeStart = new Date().getTime();

		// run the filter mNumberOfRuns times
		for (int j = 0; j < mNumberOfRuns; j++) {

			// set the original image to mImage
			mImage = FilterRunnable.deepCopy(mOrigin);

			// create the list to contain the thread
			ArrayList<Thread> threads = new ArrayList<Thread>();

			// get the interval to run several threads
			int interval = mImage.getHeight() / mCurNumThreads;

			// add the first thread to list
			threads.add(new Thread(new FilterRunnable(mWindowSize / 2, interval
					- mWindowSize / 2, mImage, mNumberOfRuns,
					mKeepThreadsRunning, mWindowSize)));
			for (int i = 2; i < mCurNumThreads + 1; i++) {

				// add the other threads
				threads.add(new Thread(
						new FilterRunnable(
								(i - 1) * interval - mWindowSize / 2, interval
										* i - mWindowSize / 2, mImage,
								mNumberOfRuns, mKeepThreadsRunning, mWindowSize)));

			}

			// start all theads in the list
			for (Thread thread : threads) {
				thread.start();
			}

			try {
				// join all thread
				for (Thread thread : threads) {
					thread.join();
				}
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
		}

		// get the end time
		long timeEnd = new Date().getTime();

		// compute the run time in milliseconds
		mRuntime = timeEnd - timeStart;

		// open the result dialog to display the filtered image
		if (!runAllTestMode) {
			new ResultDialog(mainFrame, "Result", mRuntime + "", mImage);
		}
		mImage = FilterRunnable.deepCopy(mOrigin);
	}

	/**
	 * Resize the image
	 * 
	 * @param image
	 *            The original image
	 * @param width
	 *            Width of the image after resize
	 * @param height
	 *            Height the image after resize
	 * @return BufferedImage
	 */
	public BufferedImage resize(BufferedImage image, int width, int height) {
		BufferedImage bi = new BufferedImage(width, height,
				BufferedImage.TRANSLUCENT);
		Graphics2D g2d = (Graphics2D) bi.createGraphics();
		g2d.addRenderingHints(new RenderingHints(RenderingHints.KEY_RENDERING,
				RenderingHints.VALUE_RENDER_QUALITY));
		g2d.drawImage(image, 0, 0, width, height, null);
		g2d.dispose();
		return bi;
	}

	// Starting point for the project
	public static void main(String args[]) {
		new View();

	}

	private void setDataForExperiment(int threads, int runs, int windowSize) {
		mNumberOfRuns = runs;
		mCurNumThreads = threads;
		mWindowSize = windowSize;
	}

	private void autonomoustTest() {
		int threads;
		int runs;
		int windowSize;
		int i = 0;

		runs = 1;		
		while (runs <= 15) {
			windowSize = 3;
			while (windowSize <= 15) {
				for (threads = 1; threads <= 7; threads++) {
					setDataForExperiment(threads, runs, windowSize);
					runMedianFilter(true);
					System.out.println("Case " + (++i) + ": "
							+ "\nNumber of Threads: " + threads
							+ "\nNumber of Runs: " + runs + "\nWindow Size: "
							+ windowSize + "\nRUNTIME: " + mRuntime
							+ "\n-------------------");
				}
				windowSize += 2;
			}
			runs += 5;
		}

	}
}