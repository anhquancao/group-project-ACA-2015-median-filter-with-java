/**
 * Author : Cao Anh Quan
 */
package runnable;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import javax.imageio.ImageIO;

public class FilterRunnable implements Runnable {

	private int mStartRow, mEndRow;
	private BufferedImage mImage;
	private BufferedImage mOrigin;
	private int mNumberOfRuns = 1;
	private boolean mTestThreads;
	private int mWindowSize;

	/**
	 * Constructor
	 * 
	 * @param start
	 *            Starting Index
	 * @param end
	 *            Ending Index
	 * @param image
	 *            Image to be filtered
	 * @param numRun
	 *            Number of run times
	 * @param testThreads
	 *            Whether or not keep all theads running
	 */
	public FilterRunnable(int start, int end, BufferedImage image, int numRun,
			boolean testThreads, int windowSize) {
		// TODO Auto-generated constructor stub
		mStartRow = start;
		mEndRow = end;
		mImage = image;
		mOrigin = deepCopy(image);
		mNumberOfRuns = numRun;
		mTestThreads = testThreads;
		mWindowSize = windowSize;
	}

	/**
	 * Copy the image
	 * 
	 * @param bi
	 *            The input image
	 * @return BufferedIamge
	 */
	public static BufferedImage deepCopy(BufferedImage bi) {
		ColorModel cm = bi.getColorModel();
		boolean isAlphaPremultiplied = cm.isAlphaPremultiplied();
		WritableRaster raster = bi.copyData(null);
		return new BufferedImage(cm, raster, isAlphaPremultiplied, null);
	}

	@Override
	public void run() {
		// Run the median filter
		medianFilter(mImage, mStartRow, mEndRow, mWindowSize);
		// keep all threads running for test
		while (mTestThreads) {
		}
	}

	/**
	 * Median filter
	 * 
	 * @param img
	 *            The input image
	 * @param rowStart
	 *            The stating row
	 * @param rowEnd
	 *            The ending row
	 * @return BufferedImage after filtering
	 */
	public BufferedImage medianFilter(BufferedImage img, int rowStart,
			int rowEnd, int windowSize) {
		// File f = new File("photo.jpg"); // Input Photo File
		int num = windowSize * windowSize;
		// Create the array to contain color of num pixels around
		Color[] pixel = new Color[num];

		// The R, G ,B array to contain the R, G, B value for each pixel
		int[] R = new int[num];
		int[] B = new int[num];
		int[] G = new int[num];

		int i = windowSize / 2 + 1;
		// System.out.println("bcd " + num);
		// System.out.println("abcd " + i);
		//
		for (; i < img.getWidth() - 1; i++)
			for (int j = rowStart; j < rowEnd; j++) {
				int index = 0;
				for (int k = -(windowSize / 2); k <= (windowSize / 2); k++) {
					for (int m = -(windowSize / 2); m <= (windowSize / 2); m++) {
						if (index == num) {
							break;
						}
						// System.out.println("index " + index);
						try {
							pixel[index] = new Color(mOrigin.getRGB(i + k, j
									+ m));
						} catch (Exception e) {

						}
						index += 1;
						// System.out.println("Hello " + k + " = " + m);

					}
				}

				for (int k = 0; k < num; k++) {
					// System.out.println(k);
					R[k] = pixel[k].getRed();
					B[k] = pixel[k].getBlue();
					G[k] = pixel[k].getGreen();
				}
				// Sort the array then get the median
				Arrays.sort(R);
				Arrays.sort(G);
				Arrays.sort(B);
				img.setRGB(i, j,
						new Color(R[num / 2], B[num / 2], G[num / 2]).getRGB());
			}
		//Out put to file
//		try { 													
//			File outputfile = new File("saved.png");
//			ImageIO.write(img, "png", outputfile);
//		} catch (IOException e) {
//			System.out.println("Error");
//		}
		return img;
	}

	/**
	 * Get the filtered image
	 * 
	 * @return BufferedImage
	 */
	public BufferedImage getFileredImage() {
		return mImage;
	}
}
