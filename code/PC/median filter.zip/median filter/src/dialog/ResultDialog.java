/**
 * Author : Cao Anh Quan
 */
package dialog;

import java.awt.BorderLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.KeyStroke;

public class ResultDialog extends JDialog {

	private static final long serialVersionUID = 1L;

	private BufferedImage mImage;

	public ResultDialog(JFrame parent, String title, String message,
			BufferedImage image) {
		super(parent, title); 
		System.out.println("creating the window..");

		// set the position of the window
		Point p = new Point(500, 200);

		setLocation(p.x, p.y);

		// Create a image
		JPanel imagePane = new JPanel();
		imagePane.add(new JLabel(new ImageIcon(image)));
		//Create a message
		JLabel lbMessage = new JLabel(" Runtime: "+message+" Milliseconds");
		// get content pane, which is usually the
		// Container of all the dialog's components.
		getContentPane().add(imagePane);

		// Create a button
		JPanel buttonPane = new JPanel();
		JButton button = new JButton("Close me");
		buttonPane.add(button);
		buttonPane.add(lbMessage);

		// get the image
		this.mImage = image;
		// set action listener on the button
		button.addActionListener(new MyActionListener());
		getContentPane().add(buttonPane, BorderLayout.PAGE_END);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		pack();
		setVisible(true);
	}

	// override the createRootPane inherited by the JDialog, to create the
	// rootPane.

	// create functionality to close the window when "Escape" button is pressed

	public JRootPane createRootPane() {
		JRootPane rootPane = new JRootPane();
		KeyStroke stroke = KeyStroke.getKeyStroke("ESCAPE");
		Action action = new AbstractAction() {
			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent e) {
				System.out.println("escaping..");
				setVisible(false);
				dispose();
			}

		};

		InputMap inputMap = rootPane
				.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);

		inputMap.put(stroke, "ESCAPE");

		rootPane.getActionMap().put("ESCAPE", action);

		return rootPane;

	}

	// an action listener to be used when an action is performed

	// (e.g. button is pressed)

	class MyActionListener implements ActionListener {

		// close and dispose of the window.

		public void actionPerformed(ActionEvent e) {

			System.out.println("disposing the window..");

			setVisible(false);

			dispose();

		}

	}

}
